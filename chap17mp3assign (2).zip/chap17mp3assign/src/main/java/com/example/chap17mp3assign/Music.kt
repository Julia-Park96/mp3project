package com.example.chap17mp3assign

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.Log
import java.io.Serializable

class Music(
    id: String,
    title: String?,
    artist: String?,
    albumId: String?,
    duration: Int,
    likes: Int
):
    Serializable {
    //멤버변수
    var id: String = ""
    var title: String? = null
    var artist: String? = null
    var albumId: String? = null
    var duration: Int? = 0
    var likes: Int? = 0

    //생성자 멤버변수 초기화
    init {
        this.id = id
        this.title = title
        this.artist = artist
        this.albumId = albumId
        this.duration = duration
        this.likes = likes
    }

    //컨텐트리졸버를 이용해서 음악파일 Uri 정보가져오기 위한 방법함수
    fun getAlbumUri(): Uri {
        return Uri.parse("content://media/external/audio/albumart/" + albumId)
    }

    //음악정보를 가져오기 위한 경로 Uri djerl
    fun getMusicUri(): Uri {
        return Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
    }

    fun getAlbumImage(context: Context, albumImageSize: Int): Bitmap?{
        val contentResolver: ContentResolver = context.getContentResolver()
        val uri = getAlbumUri()
        val options = BitmapFactory.Options()

        if(uri != null){
            var parcelFileDescriptor: ParcelFileDescriptor? = null
            try {
                parcelFileDescriptor = contentResolver.openFileDescriptor(uri, "r")
                var bitmap = BitmapFactory.decodeFileDescriptor(parcelFileDescriptor!!.fileDescriptor, null, options)
                if(bitmap != null){
                    if(options.outHeight !== albumImageSize || options.outWidth !==albumImageSize){
                        val tempBitmap = Bitmap.createScaledBitmap(bitmap, albumImageSize, albumImageSize, true)
                        bitmap.recycle()
                        bitmap = tempBitmap
                    }
                }
                return bitmap
            }catch (e: Exception){
                Log.d("Park", "getAlbumImage error ${e.toString()}")
            }finally {
                parcelFileDescriptor?.close()
            }
        }
        return null
    }
}